package com.OOAD;

public abstract class AbstractTuneStrategy implements TuneStrategy{
    public AbstractTuneStrategy(){

    }
}
