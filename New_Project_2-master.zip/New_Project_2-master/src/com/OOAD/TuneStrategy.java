package com.OOAD;

public interface TuneStrategy {
	public double tune();
}
