package com.OOAD;

public class Haphazard extends AbstractTuneStrategy {

	public Haphazard()
	{
	}

	@Override
	public double tune()
	{
		return 0.5;
	}

}