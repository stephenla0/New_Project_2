package com.OOAD;

public class Electronic extends AbstractTuneStrategy {

	public Electronic()
	{
	}


	@Override
	public double tune()
	{
		return 1.0;
	}
}