package com.OOAD;

public class Manual extends AbstractTuneStrategy {
	public Manual()
	{
	}


	@Override
	public double tune()
	{
		return 0.2;
	}
}