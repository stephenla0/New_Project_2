package com.OOAD;

public class Haphazard extends AbstractTuneStrategy {
	public Haphazard()
	{
	}


	@Override
	public void tune()
	{
		//out.("Tuned");
	}
}