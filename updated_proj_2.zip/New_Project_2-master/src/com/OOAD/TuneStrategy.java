package com.OOAD;

public interface TuneStrategy {
	public void tune();
}
