package com.OOAD;

public class Electronic extends AbstractTuneStrategy {

	public Electronic()
	{
	}


	@Override
	public void tune()
	{
		//out.("Tuned");
	}
}