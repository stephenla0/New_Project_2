package com.OOAD;

public class Manual extends AbstractTuneStrategy {
	public Manual()
	{
	}


	@Override
	public void tune()
	{
		//out.("Tuned");
	}
}