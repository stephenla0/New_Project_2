package com.OOAD;

// I ended up using this enum a lot!
// I essentially used it instead of bothering with a name
// by printing it out in lowercase
public enum ItemType {
    PAPERSCORE,
    CD,
    VINYL,
    CDPLAYER,
    RECORDPLAYER,
    MP3,
    GUITAR,
    BASS,
    MANDOLIN,
    FLUTE,
    HARMONICA,
    HATS,
    SHIRTS,
    BANDANAS,
    PRACTICEAMPS,
    CABLES,
    STRINGS,
    GIGBAG,
    CASSETTEPLAYER,
    CASSETTE,
    SAXOPHONE;

    private ItemType(){
    }
}
